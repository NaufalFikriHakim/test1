# Mencetak judul dari program ini
print("Biodata Anak Pacil 2021")

# Mengambil input dari pengguna dan menyimpannya ke dalam variabel-variabel
nama = input("Nama: ")
alamat = input("Alamat: ")
tempat_lahir = input("Tempat Lahir: ")
tanggal_lahir = input("Tanggal Lahir: ")
hobi = input("Hobi: ")

# Mencetak isi dari variabel-variabel
print()
print("Biodataku:")
print(nama)
print(alamat)
print(tempat_lahir)
print(tanggal_lahir)
print(hobi)